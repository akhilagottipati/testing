package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo4 {
	
		public static void main(String[] args) throws SQLException {
			String dbUrl = "jdbc:mysql://localhost:3306";
			String username = "root";
			String password = "Akhila@546";
			String query = "Use action_movies;";
			Connection con = null;
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(dbUrl, username, password);
				Statement stmt = con.createStatement();
				stmt.execute(query);
			}
			
			catch(Exception e) {
				
				e.printStackTrace();
			}
			finally {
				con.close();
			}
			
			
		}

	}


