package demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class UploadFile {
	public static void main(String[] args) throws InterruptedException, IOException {
		//1)open browser
		ChromeDriver driver = new ChromeDriver();
		
		//2)maximize it
		driver.manage().window().maximize();
		
		//3)navigate to application
		driver.get("https://www.remove.bg/");
		
		//4)click 'select files to upload' button
		//driver.findElement(By.xpath("//button[contains(@class,'btn btn-primary btn-lg')]")).click();
		driver.findElement(By.cssSelector("#page-content > div:nth-child(2) > div.flex.items-center.justify-center.overflow-x-clip > div > div > div > div.relative.group.flex.flex-col.gap-4.md\\:gap-8.max-w-md.mt-8.md\\:mt-28 > div.w-full.flex.flex-col.sm\\:justify-center.sm\\:items-center.sm\\:gap-8.sm\\:pt-36.sm\\:pb-16.rounded-4xl.bg-white.shadow-2xl > button")).click();
		Thread.sleep(3000);
		
		//5) hand over the control to autoIT
		Runtime.getRuntime().exec("resources//Fileupload.exe");
		
	}

}
