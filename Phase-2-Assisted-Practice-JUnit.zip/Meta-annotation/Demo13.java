package com.simplilearn.JUnitDemo;

public class Demo13 {
	@Fast
	public void myFastTest() {
		
	}

}
