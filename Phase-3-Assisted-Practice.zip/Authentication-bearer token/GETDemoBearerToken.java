package in.amazon.RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GETDemoBearerToken {
	
	@Test
	public void verifyResource() {
		RestAssured
		   .given()
		      .contentType("application/json")
		      .header("Authorization", "Bearer eb5a52c59ddea6c5a8c51e6eca508a6d813303aed90433c7a3ae126af834bd7c")
		    .when()
		       .get("https://gorest.co.in/public/v2/users/4494985")
		    .then()
		       .statusCode(200)
		       .log().all();
		
	}

}
