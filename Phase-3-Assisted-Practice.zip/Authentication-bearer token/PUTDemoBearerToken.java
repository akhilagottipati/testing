package in.amazon.RestAssuredDemo;

import java.util.HashMap;

import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PUTDemoBearerToken {
	HashMap<String, String> map = new HashMap<>();
	
	@BeforeMethod
	public void createPayLoad() {
		map.put("name", "antmann");
		map.put("email", "antman554466@gmail.com");
		map.put("gender", "male");
		map.put("status", "active");
		RestAssured.baseURI = "https://gorest.co.in/";
		RestAssured.basePath = "/public/v2/users/4494985";
	}
	
	@Test
	public void updateResource() {
		Response response = RestAssured
		   .given()
		      .contentType("application/json")
		      .header("Authorization", "Bearer eb5a52c59ddea6c5a8c51e6eca508a6d813303aed90433c7a3ae126af834bd7c")
		      .body(map)
		    .when()
		      .put()
		    .then()
		      .extract().response();
		
		JsonPath jsonPath = response.jsonPath();
		Assert.assertTrue(jsonPath.get("name").toString().equals("antmann"));
		
		
		
		     
	}

}
