package in.amazon.RestAssuredDemo;

public class UUIDDemo {

}
