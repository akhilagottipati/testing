package in.amazon.testscripts;


import org.testng.Assert;

import org.testng.annotations.Test;

import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;

public class VerifyErrorMessgeTest extends BaseTest {
	
	
	@Test
	public void VerifyErrorMsg() {
	//4.Hover the pointer over 'hello sign in' menu
	LandingPage landingPage = new LandingPage(driver);//class object
	landingPage.hoverOverHelloSignInMenu();
		
	//5.click on 'sign-in'button in the sub menu
	landingPage.clickSignInBtn();
		
	//6.enter invalid username in the email text box
	SignIn signIn = new SignIn(driver);
	signIn.enterEMail("batman554466@gmail.com");
    //7.click on continue button
	signIn.clickContinueBtn();
	//8. verify the error message - 'we cannot find an account with that email
	//address' is displayed to the user
	String expectedErrMsg = "We cannot find an account with that email address";
	String actualErrMsg = signIn.getErrMsg();
	Assert.assertEquals(actualErrMsg, expectedErrMsg);
}
	
}