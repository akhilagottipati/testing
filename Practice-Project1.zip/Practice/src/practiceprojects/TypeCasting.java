package practiceprojects;

public class TypeCasting {
			public static void main(String[] args) {
			// TODO Auto-generated method stub
			int num = 5;
			double num2 = num;
			System.out.println(num2);
			 
			double num3 = 8.6;
			int num4 = (int)num3;
			System.out.println(num4);

		}

	}


