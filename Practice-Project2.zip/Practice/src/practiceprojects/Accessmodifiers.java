package practiceprojects;

public class Accessmodifiers {
		 
		 // Public method accessible from anywhere
		 public void publicMethod() {
		 System.out.println("This is a public method.");
		 }
		 
		 // Protected method accessible within the same package and subclasses
		 protected void protectedMethod() {
		 System.out.println("This is a protected method.");
		 }
		 
		 // Default (package-private) method accessible within the same package
		 void defaultMethod() {
		 System.out.println("This is a default method.");
		 }
		 
		 // Private method accessible only within the same class
		 private void privateMethod() {
		 System.out.println("This is a private method.");
		 }
		 
		 // Main method
		 public static void main(String[] args) {
		 Accessmodifiers obj = new Accessmodifiers();
		 
		 // Accessing methods from the same class
		 obj.publicMethod();
		 obj.protectedMethod();
		 obj.defaultMethod();
		 obj.privateMethod();
		 }
		


}
