package practiceprojects;

public class Dowhile {
	public static void main(String[] args) {
		int i=0,n=10;
		do {
			System.out.println("value is:"+i);
			i++;
		}
		while(i<=n);
	}

}
