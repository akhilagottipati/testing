package practiceprojects;


public class ClassObjectConstructor {
	
		private String color;
		private String engineType;
		
		public ClassObjectConstructor(String colorOfCar, String typeOfEngine) {
			color = colorOfCar;
			engineType = typeOfEngine;
			}
		public void printCarPropertirs() {
			System.out.println("Color of Car = " + color);
			System.out.println("Type of Engine = " + engineType);
		}
		public static void main(String[] args) {
			ClassObjectConstructor mercedes = new ClassObjectConstructor("siver","petrol");
			
			ClassObjectConstructor audi = new ClassObjectConstructor("black","diesel");
			
			audi.printCarPropertirs();
			mercedes.printCarPropertirs();
		}

	}


