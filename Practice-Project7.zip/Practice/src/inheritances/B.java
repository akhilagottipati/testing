package inheritances;


public class B extends D{
	public void month() {
		System.out.println("It is month of june");
	}
	public static void main(String[] args) {
		B b = new B();
		b.month();
		b.date();
	}

}



