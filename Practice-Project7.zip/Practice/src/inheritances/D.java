package inheritances;
public class D {
		public void date() {
			System.out.println("It is 27-06-2023");
		}

	}
